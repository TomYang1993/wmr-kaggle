"""LaMa inpainting (big-lama TorchScript, Apache-2.0, the build IOPaint uses) for the holes that
borrowing from nearby frames cannot fill. Telea smears letter-shaped blurs into texture; LaMa
synthesises texture from the surrounding picture.
Model file: $WMR_LAMA, else <torch hub>/checkpoints/big-lama.pt, downloaded once (196 MB)."""
import hashlib
import os

import cv2
import numpy as np

URL = "https://github.com/Sanster/models/releases/download/add_big_lama/big-lama.pt"
MD5 = "e3aa4aaa15225a33ec84f9f4bc47e500"


def model_path():
    import torch
    p = os.environ.get("WMR_LAMA") or os.path.join(torch.hub.get_dir(), "checkpoints", "big-lama.pt")
    if os.path.exists(p):
        return p
    os.makedirs(os.path.dirname(p), exist_ok=True)
    tmp = p + ".part"
    torch.hub.download_url_to_file(URL, tmp, progress=False)
    h = hashlib.md5()
    with open(tmp, "rb") as fh:
        for b in iter(lambda: fh.read(1 << 20), b""):
            h.update(b)
    if h.hexdigest() != MD5:
        os.remove(tmp)
        raise RuntimeError(f"big-lama.pt download has md5 {h.hexdigest()}, expected {MD5}")
    os.replace(tmp, p)
    return p


class Lama:
    def __init__(self, device):
        import torch
        self.torch = torch
        self.dev = torch.device(device)
        import warnings
        with warnings.catch_warnings():   # torch >= 2.15 flags jit.load as deprecated; still loads
            warnings.simplefilter("ignore", FutureWarning)
            self.m = torch.jit.load(model_path(), map_location=self.dev).eval()
        self.calls = 0

    def __call__(self, bgr, mask):
        """bgr HxWx3 uint8, mask HxW bool (True = fill) -> inpainted bgr HxWx3 uint8.
        Padded to multiples of 64 (symmetric) so moving marks reuse a few input shapes.
        ponytail: one crop per call; batch a frame's crops if launch overhead shows in profiles.
        fp32 only: the model's FFT layers take fp16 only at power-of-two sizes on CUDA."""
        torch = self.torch
        h, w = mask.shape
        ph, pw = (-h) % 64, (-w) % 64
        img = np.pad(bgr[..., ::-1], ((0, ph), (0, pw), (0, 0)), mode="symmetric")
        m = np.pad(mask, ((0, ph), (0, pw)), mode="symmetric")
        with torch.inference_mode():
            x = torch.from_numpy(np.ascontiguousarray(img)).to(self.dev).permute(2, 0, 1)[None].float().div(255)
            y = torch.from_numpy(m).to(self.dev)[None, None].float()
            o = self.m(x, y)[0].permute(1, 2, 0).clamp(0, 1).mul(255).round().byte()[:h, :w].cpu().numpy()
        self.calls += 1
        return cv2.cvtColor(o, cv2.COLOR_RGB2BGR)
